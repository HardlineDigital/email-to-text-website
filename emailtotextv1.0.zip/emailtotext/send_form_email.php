<?php

if(isset($_POST['comments']))
{
if(isset($_POST['group1']))
{
	//This confirms the recipient you selected on the previous page.
	$selected_radio = $_POST['group1'];
    echo "<span>You are sending a text to : $selected_radio </span>";
}
	
	//Stores the date and time the message was sent as a variable in Eastern US Time -5:00 GMT
	//This is used in the email subject in the next stage of the application.
    date_default_timezone_set('America/New_York');
    $stamp = new DateTime();
    $stamp->getTimestamp();

	//Change Dave to whatever you changed it to on the .html file
if($selected_radio === 'Dave')
{
	// To send a text message, you must know the phone number and lookup the carrier code "example 5555555555@txt.att.net"
	// The numbers and email addresses below are fake examples.
	// This sends a message to one phone and two email addresses.
	// The subject contains a Timestamp for record keeping.
	// You can add more recipients by coping the whole elseif statements below.
	// Make sure you have a correlating radio button name on the .html page
	/* FOR EXAMPLE: COPY AND PASTE THE FOLLOWING AFTER THE LAST ELSEIF STATEMENT AND CHANGE THE RECIPIENTS/SUBJECT ETC...
	*********
	elseif($selected_radio === 'TonyB')
{
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "3525555555@txt.att.net, whoever@whatever.com, somebody@nowhere.com";
    $email_subject = $stamp->format('Y-m-d H:i:s') . " Tony B subject";
}
	*********
	*/
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "7275555555@messaging.sprintpcs.com, whoever@whatever.com, somebody@nowhere.com";
    $email_subject = $stamp->format('Y-m-d H:i:s') . " Dave subject";
}    	
elseif($selected_radio === 'TonyB')
{
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "3525555555@txt.att.net, whoever@whatever.com, somebody@nowhere.com";
    $email_subject = $stamp->format('Y-m-d H:i:s') . " Tony B subject";
}
elseif($selected_radio === 'Joe')
{
    // EDIT THE 2 LINES BELOW AS REQUIRED
    $email_to = "7275555499@messaging.sprintpcs.com, whoever@whatever.com, somebody@nowhere.com";
    $email_subject = $stamp->format('Y-m-d H:i:s') . " Joe subject";
}

     
    function died($error) {
     // You can change these error codes.
        echo "We are very sorry, but there were error(s) found with the form you submitted. ";
        echo "These errors appear below.<br /><br />";
        echo $error."<br /><br />";
        echo "Please go back and fix these errors.<br /><br />";
        die();
    }
     
    // Validate that a comment was entered
    if(!isset($_POST['comments'])) 
	{
        died('sorry, but there appears to be a problem with the form you submitted.');       
    }
	// Validate that a recipient was selected
	if(!isset($_POST['group1'])) 
	{
        died('sorry, but you did not select a recipient.');       
    }
     

    //Check with your ISP to see what is acceptable to use here.
	//You must also setup PHP to use a specific SMTP server for the outbound email.
	//Noreply@Somedomain.com is just a place holder.
    $email_from = "Noreply@Somedomain.com";
    $comments = $_POST['comments']; // required
     
    $error_message = "";
    $email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';

  if(!preg_match($email_exp,$email_from)) {
    $error_message .= 'The Email Address you entered does not appear to be valid.<br />';
  }
 
  if(strlen($comments) < 2) {
    $error_message .= 'The Comments you entered do not appear to be valid.<br />';
  }
  if(strlen($error_message) > 0) {
    died($error_message);
  }
    
     
    function clean_string($string) {
      $bad = array("content-type","bcc:","to:","cc:","href");
      return str_replace($bad,"",$string);
    }
     
    $email_message .= clean_string($comments)."\n";
     
     
// create email headers
$headers = 'From: '.$email_from."\r\n".
'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>
 
<!-- Say whatever you want to confirm the message was sent on the success page below -->
<p><img src="logo.jpg" /></p>
<p> 
Your message has been texted to the recipient's phone.</p>
Click back on your browser or <button type="button" onclick="history.go(-1);return true;"> ClickHere!</button> to send another message.
 
<?php
}
?>